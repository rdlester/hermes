package hermes.animation;
/**
 * Constants used for Animations...
 */
public interface AnimationConstants {
	
	public static final int INFINITE_LOOPS = -1;

}
