package hermes.postoffice;

/**
 * Basic interface to connect all message types.
 */
public interface Message {
	
}