package hermes.physics;

/**
 * this is a collision handler that merges beings who's shapes intersect
 * 
 * NOT YET IMPLEMENTED
 * 
 * @author Sam
 *
 * @param <A>
 */
/*
public class MassedMergeCollider<A extends MassedBeing> extends Collider<A, A>{

	public abstract class Merger {
		
		public abstract A merge(A being1, A being2);
		
		public void mergeMassedBeings(MassedBeing being1, MassedBeing being2) {
			
		}
		
	}
	
	public boolean detect(A being1, A being2) {
		if(!super.detect(being1, being2)) {
			return false;
		} else {
			MassedBeing.addMergeCollision(being1, being2);
			
			return true;
		}
	}
	
	public void handle(A being1, A being2) {
		
	}
	
	public MassedBeing mergeCollide(A being1, A being2) {
		return null;
	}
	
}
*/