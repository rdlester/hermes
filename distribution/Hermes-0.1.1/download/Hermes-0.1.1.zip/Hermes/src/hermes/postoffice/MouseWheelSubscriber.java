package src.hermes.postoffice;

public interface MouseWheelSubscriber {
	public void handleMouseWheelMessage(MouseWheelMessage m);
}
