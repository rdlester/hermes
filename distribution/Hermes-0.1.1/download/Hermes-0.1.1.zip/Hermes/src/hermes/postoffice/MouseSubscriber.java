package src.hermes.postoffice;

public interface MouseSubscriber {
	public void handleMouseMessage(MouseMessage m);
}
