package src.hermes.postoffice;

public interface KeySubscriber {
	public void handleKeyMessage(KeyMessage m);
}
