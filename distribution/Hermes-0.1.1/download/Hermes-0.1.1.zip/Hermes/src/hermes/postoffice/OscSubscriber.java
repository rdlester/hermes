package src.hermes.postoffice;

public interface OscSubscriber {
	public void handleOscMessage(OscMessage m);
}
